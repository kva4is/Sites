import React from 'react';
import { Github, Mail, ExternalLink, Send, ChevronDown, Camera, Clapperboard, Cuboid as Cube } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div className="min-h-screen flex flex-col justify-center px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <h1 className="text-5xl sm:text-7xl font-bold mb-6 tracking-tight">
          Creative
          <span className="block">Visual Artist</span>
          <span className="block text-neutral-500">Portfolio</span>
        </h1>
        <p className="text-neutral-400 text-lg sm:text-xl max-w-2xl mb-8">
          Exploring the intersection of 3D design, photography, and videography to create compelling visual narratives.
        </p>
        <div className="flex space-x-6">
          <a 
            href="https://github.com/kva4is" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="hover:text-neutral-400 transition-colors"
            aria-label="GitHub Profile"
          >
            <Github size={24} />
          </a>
          <a 
            href="https://t.me/KVA4is" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="hover:text-neutral-400 transition-colors"
            aria-label="Telegram"
          >
            <Send size={24} />
          </a>
          <a 
            href="mailto:d8278618@gmail.com" 
            className="hover:text-neutral-400 transition-colors"
            aria-label="Email"
          >
            <Mail size={24} />
          </a>
        </div>
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown size={24} />
        </div>
      </div>

      {/* Skills Section */}
      <div className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto py-20 border-t border-neutral-800">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="mb-4 flex justify-center">
              <Cube size={40} className="text-neutral-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">3D Design</h3>
            <p className="text-neutral-400">Creating immersive 3D environments and models with attention to detail and realism.</p>
          </div>
          <div className="text-center">
            <div className="mb-4 flex justify-center">
              <Camera size={40} className="text-neutral-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Photography</h3>
            <p className="text-neutral-400">Capturing moments and emotions through the lens with a focus on composition and lighting.</p>
          </div>
          <div className="text-center">
            <div className="mb-4 flex justify-center">
              <Clapperboard size={40} className="text-neutral-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Videography</h3>
            <p className="text-neutral-400">Telling stories through motion, from concept to final edit.</p>
          </div>
        </div>
      </div>

      {/* Projects Section */}
      <div className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto py-20">
        <h2 className="text-3xl font-bold mb-12">Selected Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="group relative">
              <div className="overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-[400px] object-cover transform transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="mt-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-medium">{project.title}</h3>
                  <div className="flex items-center gap-2">
                    {project.type === '3D' && <Cube size={20} />}
                    {project.type === 'Photo' && <Camera size={20} />}
                    {project.type === 'Video' && <Clapperboard size={20} />}
                    <ExternalLink size={20} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
                <p className="text-neutral-400 mt-2">{project.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-neutral-800 mt-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-neutral-400">© 2025 Portfolio. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a 
                href="mailto:d8278618@gmail.com" 
                className="text-neutral-400 hover:text-white transition-colors"
              >
                d8278618@gmail.com
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

const projects = [
  {
    title: "Abstract Geometry",
    description: "3D abstract art exploration using procedural generation",
    image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&q=80&w=1000",
    type: "3D"
  },
  {
    title: "Urban Landscapes",
    description: "Street photography series capturing city life",
    image: "https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&q=80&w=1000",
    type: "Photo"
  },
  {
    title: "Motion Stories",
    description: "Short film exploring human connections",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&q=80&w=1000",
    type: "Video"
  },
  {
    title: "Product Visualization",
    description: "3D product renders for modern tech devices",
    image: "https://images.unsplash.com/photo-1633354931133-27c285dc8c53?auto=format&fit=crop&q=80&w=1000",
    type: "3D"
  }
];

export default App;